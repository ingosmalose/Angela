
<?php $__env->startSection('content'); ?>
	<h1>About our history</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/angela/resources/views/about.blade.php ENDPATH**/ ?>