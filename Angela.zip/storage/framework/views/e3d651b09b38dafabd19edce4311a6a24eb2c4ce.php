
<?php $__env->startSection('content'); ?>
	<h1>Healt</h1>
	<p>Let me know what is important for you and I help you</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/angela/resources/views/healt.blade.php ENDPATH**/ ?>