@extends('layouts.master')
@section('content')
	<h1>Contact</h1>
	<p>Let me know what is important for you and I help you</p>
@stop