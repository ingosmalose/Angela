<!-- sidebar nav -->
<div class="nav">
	<ul class="nav flex-column blue lighten-5 py-4">
		<li><a href="store">Stores</a></li>
		<li><a href="item">Articles</a></li>
		<li><a href="food">Food</a></li>
		<li><a href="furnitures">Furnitures</a></li>
		<li><a href="healt">Healt</a></li>
		<li><a href="school">School</a></li>
		<li><a href="sport">Sport</a></li>		
	</ul>
</div>
