@extends('layouts.master')
@section('title', 'Test Page')
@section('content')
	<h1>About our history</h1>
@stop