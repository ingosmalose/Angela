@extends('layouts.master')
@section('content')
	<h1>Project</h1>
@stop